package com.vuclip.all_latest_apis.utils;

public class Constants {

	public static final String FILE_PATH="C:\\Users\\mohitpat\\mission_learning\\ALL_LATEST_APIS\\input.txt";
	public static final String API_NAME="All Latest APIs";
}
