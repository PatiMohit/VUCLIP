package com.vuclip.all_latest_apis.bo;

public interface ProcessText {

	void process();
}
